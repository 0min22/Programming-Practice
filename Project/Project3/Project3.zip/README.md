# WZT Drawing-Based Early Depression Prediction Prototype

이 프로젝트는 Kim et al. (2025), *Predicting early depression in WZT drawing image based on deep learning*의 아이디어를 바탕으로 구성한 연구형 프로토타입입니다.

## 핵심 목적

실제 WZT 우울 데이터는 개인정보 및 윤리 문제로 공개되어 있지 않으므로, 본 프로젝트는 실제 의료 진단 모델이 아니라 다음 목적의 synthetic experimental prototype입니다.

1. WZT 자극 그림 기반 이미지 분류 파이프라인 구현
2. CNN-SoftMax 모델 재구성
3. CNN-SVM 스타일 hinge-loss 모델 비교
4. synthetic WZT 데이터 생성 규칙의 명시적 기록
5. 기존 handcrafted feature 기반 ML 프로젝트와 비교 가능한 구조 구성

## 실행 순서

```bash
pip install -r requirements.txt

python src/01_generate_wzt_dataset.py --out data/synthetic_wzt --n_depressed 600 --n_non_depressed 600 --seed 42

python src/02_train_cnn.py --data data/synthetic_wzt --model_type softmax --epochs 30 --out results_softmax

python src/02_train_cnn.py --data data/synthetic_wzt --model_type hinge --epochs 30 --out results_hinge

python src/03_evaluate_and_gradcam.py --data data/synthetic_wzt --model results_softmax/model.keras --out results_softmax
```

## 주의

이 데이터는 실제 임상 데이터가 아닙니다. 따라서 결과는 질병 진단 성능이 아니라, 논문 기반 방법론을 구현하고 실험 설계를 보여주는 용도로 해석해야 합니다.
